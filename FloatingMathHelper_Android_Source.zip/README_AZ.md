# Floating Math Helper — Doğru/Yanlış prototipi

Android/Kotlin prototipi: ekranda üzən düymə, MediaProjection ilə istifadəçinin təsdiqlədiyi ekran görüntüsü, ML Kit OCR və toplama/çıxma bərabərlik yoxlaması.

## Nə edir?
Düyməyə toxunanda ekran görüntüsündə `2 + 2 = 5`, `120 - 30 = 90`, `8+7=15` tipli ifadə axtarır. Hər iki tərəfi hesablayıb böyük **DOĞRU** və ya **YANLIŞ** yazır.

## Məhdudiyyətlər
- Yalnız tam ədədlərlə toplama və çıxma üçün başlanğıc prototipidir.
- Ən çox dörd rəqəmli ədədləri tanımağa çalışır; istifadəçinin əsas hədəfi olan 1–3 rəqəmli ədədlər də uyğundur.
- OCR `1` ilə `7` kimi simvolları səhv oxuya bilər. Nəticəni səhv göstərə bilər.
- “Bir saniyəyə zəmanət” yoxdur; cihazdan, animasiyadan və OCR-dən asılıdır.
- Tətbiqlər ekran görüntüsünü bloklaya bilər.
- Tənlik, vurma/bölmə, kəsr, vektor, matris, törəmə və inteqral üçün deyil.

## Quraşdırma
1. ZIP-i kompüterə çıxart.
2. Android Studio-da qovluğu aç.
3. JDK 17 ilə Gradle sinxronizasiyasını tamamla.
4. USB debugging aktiv Android telefonunu qoş və Run et.
5. Tətbiqdə `Allow overlay` seç, sistem ayarlarında icazəni ver.
6. `Start helper` bas və ekran paylaşımı sorğusunu təsdiqlə.
7. Başqa tətbiqdə sağ kənardakı `∑` düyməsinə toxun. Cavab ekranda görünəcək.
8. Xidmətin dayanması üçün tətbiqə qayıdıb `Stop helper` bas.

## İcazələr
`SYSTEM_ALERT_WINDOW` üzən düymə üçündür; foreground service və MediaProjection icazələri ekranı oxumaq üçündür. Ekran paylaşımı hər dəfə istifadəçinin sistem pəncərəsində təsdiqindən asılıdır.

Bu mənbə kodu nümunə/prototipdir. Bu mühitdə Android build-i aparılmayıb və real telefonda sınaqdan keçirildiyi iddia edilmir.
