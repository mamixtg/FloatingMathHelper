plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.floatingmath"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.floatingmath"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
dependencies {
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("net.objecthunter:exp4j:0.4.8")
}
