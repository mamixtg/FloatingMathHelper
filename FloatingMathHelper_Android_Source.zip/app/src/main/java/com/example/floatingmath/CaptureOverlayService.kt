package com.example.floatingmath

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import net.objecthunter.exp4j.ExpressionBuilder
import java.util.concurrent.atomic.AtomicBoolean

class CaptureOverlayService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL_ID = "math_helper"
        private const val NOTIFICATION_ID = 42
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var overlay: Button? = null
    private var resultView: TextView? = null
    private lateinit var windowManager: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val scanning = AtomicBoolean(false)
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            startCapture()
            showOverlay()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not start screen capture: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startCapture() {
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi
        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3)
        virtualDisplay = projection?.createVirtualDisplay(
            "FloatingMathCapture", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader!!.surface, null, handler
        )
    }

    private fun showOverlay() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val button = Button(this).apply {
            text = "∑"
            textSize = 20f
            setOnClickListener { scanScreen() }
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            x = 12
        }
        windowManager.addView(button, params)
        overlay = button
    }

    private fun scanScreen() {
        if (!scanning.compareAndSet(false, true)) return
        overlay?.text = "…"
        handler.postDelayed({
            val reader = imageReader
            val image = reader?.acquireLatestImage()
            if (image == null) {
                scanning.set(false)
                overlay?.text = "∑"
                Toast.makeText(this, "Screen image not ready. Tap again.", Toast.LENGTH_SHORT).show()
                return@postDelayed
            }
            val plane = image.planes[0]
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * image.width
            val bitmap = Bitmap.createBitmap(
                image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888
            )
            bitmap.copyPixelsFromBuffer(plane.buffer)
            image.close()
            val cropped = Bitmap.createBitmap(bitmap, 0, 0, image.width, image.height)
            bitmap.recycle()
            recognizer.process(InputImage.fromBitmap(cropped, 0))
                .addOnSuccessListener { visionText ->
                    val text = visionText.text
                    val answer = findAndSolve(text)
                    showResult(answer ?: "No simple arithmetic expression found")
                }
                .addOnFailureListener {
                    showResult("Could not read the screen")
                }
                .addOnCompleteListener {
                    cropped.recycle()
                    scanning.set(false)
                    overlay?.text = "∑"
                }
        }, 250)
    }


    private fun findAndSolve(ocrText: String): String? {
        // Fast starter checker for simple true/false arithmetic:
        // examples: 2 + 2 = 5, 120 - 30 = 90, 8+7=15
        // Intentionally does not attempt algebra or complex formulas.
        val cleaned = ocrText
            .replace('×', '*')
            .replace('÷', '/')
            .replace('−', '-')
            .replace('–', '-')
            .replace('＝', '=')
            .replace(',', '.')

        // Prefer a line containing an equality, since the task is to judge it.
        for (rawLine in cleaned.lines().asReversed()) {
            val line = rawLine
            val eq = Regex("""([0-9\s+\-().]{1,40})=([0-9\s+\-().]{1,20})""").find(line)
                ?: continue
            val left = evaluateAddSubtract(eq.groupValues[1]) ?: continue
            val right = evaluateAddSubtract(eq.groupValues[2]) ?: continue
            return if (left == right) "DOĞRU" else "YANLIŞ"
        }
        return null
    }

    private fun evaluateAddSubtract(source: String): Long? {
        val s = source.replace(" ", "")
        if (s.isEmpty() || s.length > 40) return null
        // Accept only integer addition/subtraction, including parentheses-free expressions.
        if (!Regex("""[+-]?\d{1,4}(?:[+-]\d{1,4})*""").matches(s)) return null
        return try {
            val tokens = Regex("""[+-]?\d+""").findAll(s).map { it.value.toLong() }.toList()
            if (tokens.isEmpty()) null else tokens.sum()
        } catch (_: Exception) {
            null
        }
    }

    private fun showResult(message: String) {
        handler.post {
            resultView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
            val view = TextView(this).apply {
                text = message
                textSize = 26f
                setPadding(28, 20, 28, 20)
                setBackgroundColor(0xF0222222.toInt())
                setTextColor(if (message == "DOĞRU") 0xFF65E68A.toInt()
                    else if (message == "YANLIŞ") 0xFFFF7777.toInt()
                    else 0xFFFFFFFF.toInt())
                setOnClickListener {
                    try { windowManager.removeView(this) } catch (_: Exception) {}
                    resultView = null
                }
            }
            val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                y = 120
            }
            windowManager.addView(view, params)
            resultView = view
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Math helper", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL_ID) else @Suppress("DEPRECATION") Notification.Builder(this)
        return builder.setContentTitle("Floating Math Helper")
            .setContentText("Screen capture is active. Tap ∑ to scan.")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .build()
    }

    override fun onDestroy() {
        try { overlay?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        try { resultView?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        virtualDisplay?.release()
        imageReader?.close()
        projection?.stop()
        recognizer.close()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
